import { useState } from 'react';
import {
  User as UserIcon, Mail, Phone, GraduationCap, MapPin, Linkedin, Github, Globe,
  Target, Building2, Edit3, Save, X, Award, Briefcase,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { demoUser } from '@/data/demoData';

export function ProfilePage() {
  const { user, setUser } = useAuth();
  const profile = user || demoUser;
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(profile);

  const handleSave = () => {
    setUser(form);
    setEditing(false);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header card */}
      <div className="card overflow-hidden">
        <div className="h-28 bg-gradient-to-br from-primary-600 via-primary-700 to-primary-900 relative">
          <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-accent-400/15 blur-3xl -translate-y-1/3 translate-x-1/4" />
        </div>
        <div className="px-6 pb-6 -mt-12 relative">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-accent-400 to-accent-600 flex items-center justify-center text-white text-3xl font-bold font-display ring-4 ring-white shadow-lg shrink-0">
              {profile.name?.charAt(0) || 'A'}
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-bold font-display text-ink-900">{profile.name}</h1>
              <p className="text-sm text-ink-500">{profile.email}</p>
            </div>
            {!editing ? (
              <button onClick={() => setEditing(true)} className="btn-secondary">
                <Edit3 className="w-4 h-4" /> Edit Profile
              </button>
            ) : (
              <div className="flex gap-2">
                <button onClick={() => { setForm(profile); setEditing(false); }} className="btn-secondary">
                  <X className="w-4 h-4" /> Cancel
                </button>
                <button onClick={handleSave} className="btn-primary">
                  <Save className="w-4 h-4" /> Save
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Personal info */}
        <div className="card p-6 lg:col-span-2">
          <h3 className="section-title mb-4">Personal Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InfoField icon={<UserIcon className="w-4 h-4" />} label="Full Name" value={form.name} editing={editing}
              onChange={(v) => setForm({ ...form, name: v })} />
            <InfoField icon={<Mail className="w-4 h-4" />} label="Email" value={form.email} editing={editing}
              onChange={(v) => setForm({ ...form, email: v })} />
            <InfoField icon={<Phone className="w-4 h-4" />} label="Phone" value={form.phone || ''} editing={editing}
              onChange={(v) => setForm({ ...form, phone: v })} />
            <InfoField icon={<Building2 className="w-4 h-4" />} label="University" value={form.university} editing={editing}
              onChange={(v) => setForm({ ...form, university: v })} />
            <InfoField icon={<GraduationCap className="w-4 h-4" />} label="Branch" value={form.branch} editing={editing}
              onChange={(v) => setForm({ ...form, branch: v })} />
            <InfoField icon={<MapPin className="w-4 h-4" />} label="Year" value={form.year} editing={editing}
              onChange={(v) => setForm({ ...form, year: v })} />
            <InfoField icon={<Award className="w-4 h-4" />} label="CGPA" value={String(form.cgpa)} editing={editing}
              onChange={(v) => setForm({ ...form, cgpa: parseFloat(v) || 0 })} />
            <InfoField icon={<Target className="w-4 h-4" />} label="Target Role" value={form.target_role} editing={editing}
              onChange={(v) => setForm({ ...form, target_role: v })} />
          </div>
        </div>

        {/* Links + targets */}
        <div className="space-y-6">
          <div className="card p-6">
            <h3 className="section-title mb-4">Social Links</h3>
            <div className="space-y-3">
              <LinkField icon={<Linkedin className="w-4 h-4" />} label="LinkedIn" value={form.linkedin_url || ''} editing={editing}
                onChange={(v) => setForm({ ...form, linkedin_url: v })} color="text-[#0A66C2]" />
              <LinkField icon={<Github className="w-4 h-4" />} label="GitHub" value={form.github_url || ''} editing={editing}
                onChange={(v) => setForm({ ...form, github_url: v })} color="text-ink-700" />
              <LinkField icon={<Globe className="w-4 h-4" />} label="Portfolio" value={form.portfolio_url || ''} editing={editing}
                onChange={(v) => setForm({ ...form, portfolio_url: v })} color="text-accent-600" />
            </div>
          </div>

          <div className="card p-6">
            <h3 className="section-title mb-4">Target Companies</h3>
            <div className="flex flex-wrap gap-2">
              {form.target_companies.map((c) => (
                <span key={c} className="badge-primary">
                  <Briefcase className="w-3 h-3" /> {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoField({
  icon, label, value, editing, onChange,
}: {
  icon: React.ReactNode; label: string; value: string; editing: boolean; onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      {editing ? (
        <div className="relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400">{icon}</span>
          <input className="input pl-10" value={value} onChange={(e) => onChange(e.target.value)} />
        </div>
      ) : (
        <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-ink-50/50">
          <span className="text-ink-400">{icon}</span>
          <span className="text-sm text-ink-800">{value || '—'}</span>
        </div>
      )}
    </div>
  );
}

function LinkField({
  icon, label, value, editing, onChange, color,
}: {
  icon: React.ReactNode; label: string; value: string; editing: boolean; onChange: (v: string) => void; color: string;
}) {
  return (
    <div>
      <label className="text-xs font-medium text-ink-500 mb-1 block">{label}</label>
      {editing ? (
        <input className="input" value={value} onChange={(e) => onChange(e.target.value)} placeholder={`Add ${label} URL`} />
      ) : (
        <a href={value || '#'} target="_blank" rel="noreferrer" className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-ink-50/50 hover:bg-ink-50 transition-colors ${value ? '' : 'opacity-50 pointer-events-none'}`}>
          <span className={color}>{icon}</span>
          <span className="text-sm text-ink-700 truncate">{value || 'Not added'}</span>
        </a>
      )}
    </div>
  );
}
