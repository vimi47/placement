import { useParams, useNavigate } from 'react-router-dom';
import {
  Code2, Brain, Clock, CheckCircle2, Play, Trophy, Star, ArrowLeft,
} from 'lucide-react';
import { SectionHeader, EmptyState, ProgressBar } from '@/components/ui';
import { demoCodingAssessments, demoAptitudeAssessments } from '@/data/demoData';
import type { Assessment } from '@/types';

export function AssessmentsPage() {
  const { type } = useParams<{ type: string }>();
  const navigate = useNavigate();
  const isCoding = type === 'coding';
  const assessments: Assessment[] = isCoding ? demoCodingAssessments : demoAptitudeAssessments;

  const icon = isCoding ? <Code2 className="w-5 h-5" /> : <Brain className="w-5 h-5" />;
  const title = isCoding ? 'Coding Assessments' : 'Aptitude Assessments';
  const subtitle = isCoding
    ? 'Practice DSA problems — arrays, trees, DP, graphs, and more'
    : 'Quantitative, logical reasoning, verbal ability, and data interpretation';

  const completed = assessments.filter((a) => a.status === 'completed');
  const inProgress = assessments.filter((a) => a.status === 'in-progress');
  const avgScore = completed.length > 0
    ? Math.round(completed.reduce((acc, a) => acc + (a.score || 0), 0) / completed.length)
    : 0;

  const difficultyBadge = (d: string) => {
    if (d === 'Easy') return 'badge-success';
    if (d === 'Medium') return 'badge-warning';
    return 'badge-error';
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <SectionHeader
        title={title}
        subtitle={subtitle}
        icon={icon}
        action={
          <div className="flex gap-3">
            <div className="text-center">
              <p className="text-2xl font-bold font-display text-ink-900">{completed.length}</p>
              <p className="text-xs text-ink-400">Completed</p>
            </div>
            <div className="w-px bg-ink-100" />
            <div className="text-center">
              <p className="text-2xl font-bold font-display text-success-600">{avgScore || '—'}</p>
              <p className="text-xs text-ink-400">Avg Score</p>
            </div>
          </div>
        }
      />

      {/* In progress */}
      {inProgress.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-ink-500 uppercase tracking-wide">Continue</h3>
          {inProgress.map((a) => (
            <div key={a.id} className="card p-5 border-l-4 border-l-primary-400">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-ink-900">{a.title}</h4>
                    <span className="badge-primary text-[10px]">In Progress</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-ink-400">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {a.duration_minutes} min</span>
                    <span className={difficultyBadge(a.difficulty)}>{a.difficulty}</span>
                    <span className="flex flex-wrap gap-1">
                      {a.topics.map((t) => <span key={t} className="badge-neutral text-[10px]">{t}</span>)}
                    </span>
                  </div>
                </div>
                <button className="btn-primary text-sm">Resume</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Available */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-ink-500 uppercase tracking-wide">Available Assessments</h3>
        {assessments.filter((a) => a.status !== 'in-progress').length === 0 ? (
          <EmptyState
            icon={<Code2 className="w-7 h-7" />}
            title="No assessments available"
            description="Check back later for new assessments."
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assessments
              .filter((a) => a.status !== 'in-progress')
              .map((a) => (
                <div key={a.id} className="card card-hover p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-ink-50 flex items-center justify-center">
                      {a.status === 'completed' ? (
                        <Trophy className="w-5 h-5 text-warning-500" />
                      ) : (
                        isCoding ? <Code2 className="w-5 h-5 text-primary-600" /> : <Brain className="w-5 h-5 text-accent-600" />
                      )}
                    </div>
                    <span className={difficultyBadge(a.difficulty)}>{a.difficulty}</span>
                  </div>
                  <h4 className="font-semibold text-ink-900 text-sm">{a.title}</h4>
                  <div className="flex items-center gap-3 mt-2 text-xs text-ink-400">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {a.duration_minutes} min</span>
                    <span>·</span>
                    <span>{a.topics.join(', ')}</span>
                  </div>

                  {a.status === 'completed' && (
                    <div className="mt-3 pt-3 border-t border-ink-100">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs text-ink-500">Your Score</span>
                        <span className="text-sm font-bold text-ink-900">{a.score}/{a.max_score}</span>
                      </div>
                      <ProgressBar value={a.score || 0} max={a.max_score} color={a.score && a.score >= 80 ? 'bg-success-500' : 'bg-warning-500'} height="h-1.5" />
                    </div>
                  )}

                  <div className="mt-4">
                    {a.status === 'completed' ? (
                      <button className="btn-secondary w-full text-sm">
                        <Star className="w-3.5 h-3.5" /> View Results
                      </button>
                    ) : (
                      <button className="btn-primary w-full text-sm">
                        <Play className="w-3.5 h-3.5" /> Start Assessment
                      </button>
                    )}
                  </div>
                </div>
              ))
            }
          </div>
        )}
      </div>

      {/* Switch type */}
      <div className="flex justify-center pt-2">
        <button
          onClick={() => navigate(isCoding ? '/assessments/aptitude' : '/assessments/coding')}
          className="btn-secondary text-sm"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Switch to {isCoding ? 'Aptitude' : 'Coding'} Assessments
        </button>
      </div>
    </div>
  );
}
