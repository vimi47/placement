import { useState, useRef } from 'react';
import {
  FileText, Upload, CheckCircle2, AlertCircle, Lightbulb, Sparkles,
  TrendingUp, Download, RefreshCw,
} from 'lucide-react';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Cell,
} from 'recharts';
import { ProgressRing, SectionHeader, LoadingState } from '@/components/ui';
import { demoATSResult } from '@/data/demoData';

export function ResumePage() {
  const [result, setResult] = useState(demoATSResult);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    // Simulate upload + analysis
    setTimeout(() => {
      setResult(demoATSResult);
      setUploading(false);
    }, 2000);
  };

  const scoreColor = (score: number) => {
    if (score >= 80) return '#25c883';
    if (score >= 60) return '#ff8d0d';
    return '#e22d2d';
  };

  const chartData = result.sections.map((s) => ({ name: s.name.split(' ')[0], score: s.score }));

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <SectionHeader
        title="Resume / ATS Analysis"
        subtitle="AI-powered resume scoring with ATS keyword optimization"
        icon={<FileText className="w-5 h-5" />}
      />

      {/* Upload zone */}
      <div className="card p-6">
        <input ref={fileRef} type="file" accept=".pdf,.doc,.docx" className="hidden" onChange={handleUpload} />
        {!uploading ? (
          <div
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed border-ink-200 rounded-xl py-10 flex flex-col items-center justify-center cursor-pointer hover:border-primary-400 hover:bg-primary-50/30 transition-all"
          >
            <div className="w-14 h-14 rounded-2xl bg-primary-50 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6 text-primary-600" />
            </div>
            <p className="text-sm font-medium text-ink-700">Click to upload your resume</p>
            <p className="text-xs text-ink-400 mt-1">PDF, DOC, or DOCX — max 5MB</p>
          </div>
        ) : (
          <div className="py-10 flex flex-col items-center">
            <div className="w-14 h-14 border-3 border-ink-100 border-t-primary-500 rounded-full animate-spin mb-3" />
            <p className="text-sm text-ink-500">Analyzing your resume with AI...</p>
            <p className="text-xs text-ink-400 mt-1">Extracting keywords, scoring sections, generating suggestions</p>
          </div>
        )}
      </div>

      {result && !uploading && (
        <>
          {/* Overall score */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="card p-6 flex flex-col items-center justify-center">
              <ProgressRing
                value={result.overall_score}
                label={`${result.overall_score}`}
                sublabel="ATS Score"
                size={140}
                color={scoreColor(result.overall_score)}
              />
              <div className="mt-3 text-center">
                <span className={`badge ${result.overall_score >= 80 ? 'badge-success' : result.overall_score >= 60 ? 'badge-warning' : 'badge-error'}`}>
                  {result.overall_score >= 80 ? 'Good match' : result.overall_score >= 60 ? 'Needs improvement' : 'Below threshold'}
                </span>
              </div>
              <p className="text-xs text-ink-400 mt-2">File: {result.file_name}</p>
            </div>

            <div className="card p-6 lg:col-span-2">
              <h3 className="section-title mb-4">Section Scores</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData} layout="vertical" margin={{ left: 0, right: 16 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#eceef2" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: '#8593aa' }} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#677591' }} axisLine={false} tickLine={false} width={70} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: '1px solid #eceef2', fontSize: 13 }}
                    cursor={{ fill: '#f6f7f9' }}
                  />
                  <Bar dataKey="score" radius={[0, 6, 6, 0]}>
                    {chartData.map((entry, i) => (
                      <Cell key={i} fill={scoreColor(entry.score)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Section breakdown */}
          <div className="card p-6">
            <h3 className="section-title mb-4">Detailed Section Analysis</h3>
            <div className="space-y-4">
              {result.sections.map((section) => (
                <div key={section.name} className="p-4 rounded-xl border border-ink-100 hover:border-ink-200 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-ink-800 text-sm">{section.name}</h4>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-1.5 bg-ink-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${section.score}%`, backgroundColor: scoreColor(section.score) }} />
                      </div>
                      <span className="text-sm font-semibold" style={{ color: scoreColor(section.score) }}>{section.score}</span>
                    </div>
                  </div>
                  <p className="text-sm text-ink-500 mb-3">{section.feedback}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {section.keywords_found.map((k) => (
                      <span key={k} className="badge-success text-[11px]"><CheckCircle2 className="w-3 h-3" /> {k}</span>
                    ))}
                    {section.keywords_missing.map((k) => (
                      <span key={k} className="badge-error text-[11px]"><AlertCircle className="w-3 h-3" /> {k}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Suggestions + parsed skills */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-warning-50 flex items-center justify-center">
                  <Lightbulb className="w-4 h-4 text-warning-600" />
                </div>
                <h3 className="section-title">AI Suggestions</h3>
              </div>
              <div className="space-y-3">
                {result.suggestions.map((s, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-ink-50/50">
                    <span className="w-6 h-6 rounded-full bg-warning-100 text-warning-700 text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    <p className="text-sm text-ink-600">{s}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="card p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-accent-50 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-accent-600" />
                </div>
                <h3 className="section-title">Parsed Skills</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {result.parsed_skills.map((s) => (
                  <span key={s} className="badge-accent">{s}</span>
                ))}
              </div>
              <div className="mt-6 pt-6 border-t border-ink-100">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-primary-600" />
                  <h4 className="text-sm font-semibold text-ink-700">Quick Actions</h4>
                </div>
                <div className="flex gap-2">
                  <button className="btn-secondary text-xs">
                    <Download className="w-3.5 h-3.5" /> Download Report
                  </button>
                  <button onClick={() => fileRef.current?.click()} className="btn-secondary text-xs">
                    <RefreshCw className="w-3.5 h-3.5" /> Re-analyze
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
