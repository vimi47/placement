import { Map, CheckCircle2, Circle, Clock, BookOpen, Award, Code2, ChevronDown } from 'lucide-react';
import { SectionHeader, ProgressBar } from '@/components/ui';
import { demoRoadmap } from '@/data/demoData';
import { useState } from 'react';

export function RoadmapPage() {
  const [expandedPhase, setExpandedPhase] = useState<string | null>(
    demoRoadmap.find((p) => p.status === 'in-progress')?.id || null
  );

  const statusIcon = (status: string) => {
    if (status === 'completed') return <CheckCircle2 className="w-5 h-5 text-success-500" />;
    if (status === 'in-progress') return <Clock className="w-5 h-5 text-primary-500 animate-pulse" />;
    return <Circle className="w-5 h-5 text-ink-300" />;
  };

  const resourceIcon = (type: string) => {
    switch (type) {
      case 'course': return <BookOpen className="w-3.5 h-3.5" />;
      case 'project': return <Code2 className="w-3.5 h-3.5" />;
      case 'certification': return <Award className="w-3.5 h-3.5" />;
      default: return <BookOpen className="w-3.5 h-3.5" />;
    }
  };

  const totalTasks = demoRoadmap.reduce((acc, p) => acc + p.tasks.length, 0);
  const completedTasks = demoRoadmap.reduce((acc, p) => acc + p.tasks.filter((t) => t.status === 'completed').length, 0);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <SectionHeader
        title="Personalized Roadmap"
        subtitle="AI-generated learning path adapted to your progress"
        icon={<Map className="w-5 h-5" />}
        action={
          <div className="text-right">
            <p className="text-2xl font-bold font-display text-ink-900">{completedTasks}/{totalTasks}</p>
            <p className="text-xs text-ink-400">Tasks completed</p>
          </div>
        }
      />

      {/* Timeline */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-[22px] top-0 bottom-0 w-0.5 bg-ink-100" />

        <div className="space-y-4">
          {demoRoadmap.map((phase, idx) => (
            <div key={phase.id} className="relative pl-14">
              {/* Node */}
              <div className="absolute left-0 top-1 w-11 h-11 rounded-full bg-white border-2 border-ink-100 flex items-center justify-center z-10">
                {statusIcon(phase.status)}
              </div>

              {/* Card */}
              <div className="card card-hover overflow-hidden">
                <button
                  onClick={() => setExpandedPhase(expandedPhase === phase.id ? null : phase.id)}
                  className="w-full text-left p-5 flex items-center justify-between gap-4"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-ink-400">Phase {idx + 1}</span>
                      <span className={`badge ${
                        phase.status === 'completed' ? 'badge-success' :
                        phase.status === 'in-progress' ? 'badge-primary' : 'badge-neutral'
                      }`}>
                        {phase.status === 'in-progress' ? 'In Progress' : phase.status}
                      </span>
                    </div>
                    <h3 className="font-semibold text-ink-900">{phase.title}</h3>
                    <p className="text-xs text-ink-400 mt-0.5">
                      {phase.duration_weeks} weeks · {phase.tasks.length} tasks
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="w-24 hidden sm:block">
                      <ProgressBar value={phase.progress} height="h-1.5" />
                    </div>
                    <span className="text-sm font-semibold text-ink-700">{phase.progress}%</span>
                    <ChevronDown className={`w-4 h-4 text-ink-400 transition-transform ${expandedPhase === phase.id ? 'rotate-180' : ''}`} />
                  </div>
                </button>

                {expandedPhase === phase.id && (
                  <div className="border-t border-ink-100 p-5 bg-ink-50/30 animate-fade-in">
                    <div className="space-y-2.5">
                      {phase.tasks.map((task) => (
                        <div key={task.id} className="flex items-start gap-3 p-3 rounded-xl bg-white border border-ink-100 hover:border-ink-200 transition-colors">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                            task.status === 'completed' ? 'bg-success-500' :
                            task.status === 'in-progress' ? 'bg-primary-500' : 'bg-ink-200'
                          }`}>
                            {task.status === 'completed' && <CheckCircle2 className="w-3 h-3 text-white" />}
                            {task.status === 'in-progress' && <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className={`text-sm font-medium ${task.status === 'completed' ? 'text-ink-400 line-through' : 'text-ink-800'}`}>
                                {task.title}
                              </h4>
                              <span className="badge-neutral text-[10px]">
                                {resourceIcon(task.resource_type)} {task.resource_type}
                              </span>
                            </div>
                            <p className="text-xs text-ink-400 mt-0.5">{task.description}</p>
                          </div>
                          <span className="text-xs text-ink-400 shrink-0">{task.estimated_hours}h</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
